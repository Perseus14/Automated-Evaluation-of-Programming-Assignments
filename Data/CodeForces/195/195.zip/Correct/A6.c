#include <stdio.h>
int main()
{
    int a,b,c,ans;
    scanf("%d%d%d",&a,&b,&c);
    ans=((a-b)*c+b-1)/b;
    printf("%d\n",ans);
    return 0;
}

	  		 	 		     					   	 	  	